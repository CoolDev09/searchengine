# Code monkey search
Simple web search engine made for fun

# YouTube series
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/prawW1weCwE/0.jpg)](https://www.youtube.com/watch?v=9lQQTlCoKW0&list=PLLfIBXQeu3aabb1aeRqrTBZPozDU9Qwz0)
